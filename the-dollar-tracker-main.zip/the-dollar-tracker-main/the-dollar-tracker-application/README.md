[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/8Cy36LS2)
[![Work in MakeCode](https://classroom.github.com/assets/work-in-make-code-8824cc13a1a3f34ffcd245c82f0ae96fdae6b7d554b6539aec3a03a70825519c.svg)](https://classroom.github.com/online_ide?assignment_repo_id=21523062&assignment_repo_type=AssignmentRepo)
# Assignment 2 – Low-Fidelity Prototype

## What to Submit

- Upload your report in the `/docs` folder

## Folder Structure
- `/docs/report.pdf`

## Submission Notes
Push all files before the deadline. This repo is private and only visible to you and instructors.
# Synced update - Added ProjectTemplatee
