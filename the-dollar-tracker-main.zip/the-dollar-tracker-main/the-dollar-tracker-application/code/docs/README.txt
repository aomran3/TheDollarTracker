The Dollar Tracker — Clean Qt6 Project
Run: Open CMakeLists.txt in Qt Creator (Qt 6.10 Desktop kit), build, run.
Default data folder: ~/Desktop/dollar_files  (auto-created if missing)
Override with env var: DOLLAR_DATA_DIR
Login IDs: mg3307 (manager) or emp312 (employee)
Deliverable 2 Video Walkthrough link: https://youtu.be/gVKN-shCQIg 
Deliverable 3 Video Walkthrough link: https://youtu.be/buFA73xWPoM?si=Pm07eGsRYWNOY8KP
