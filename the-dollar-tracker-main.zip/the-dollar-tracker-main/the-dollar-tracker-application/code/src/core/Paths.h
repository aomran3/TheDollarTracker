#pragma once
#include <QString>
namespace Paths {
QString dataDir();
QString file(const QString& name);
}
