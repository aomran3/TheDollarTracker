#ifndef TEST_FILEGATEWAY_MOCK_H
#define TEST_FILEGATEWAY_MOCK_H

class test_filegateway_mock
{
public:
    test_filegateway_mock();
};

#endif // TEST_FILEGATEWAY_MOCK_H
