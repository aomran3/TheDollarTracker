#ifndef TEST_PAYROLL_H
#define TEST_PAYROLL_H

class test_payroll
{
public:
    test_payroll();
};

#endif // TEST_PAYROLL_H
