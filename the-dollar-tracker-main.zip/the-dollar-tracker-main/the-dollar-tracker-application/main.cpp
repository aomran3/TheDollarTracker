#include <iostream>
using namespace std;

int main() {
    cout << "Hello Assignment 2!" << endl;
    return 0;
}
